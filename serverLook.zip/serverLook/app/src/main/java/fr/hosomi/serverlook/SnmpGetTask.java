package fr.hosomi.serverlook;

/**
 * Created by Alex on 10/03/15.
 */
public class SnmpGetTask {

    public boolean erreurFlag;

    public void onPreExecute(){

    }

    public String doInBackground(String[] a){

       return null;
    }

    public void onPostExecute(String[] a){

    }


}
